Финальные правки сайта

Что исправлено:
1. Добавлена постоянная плавающая кнопка WhatsApp справа снизу.
   Она остаётся на экране при прокрутке вверх и вниз.
   На компьютере отображается как кнопка WhatsApp, на телефоне — круглая зелёная иконка.

2. Все ссылки WhatsApp теперь ведут сразу в WhatsApp через wa.me.
   Номер и текст сообщения меняются в файле:
   includes/config.php
   Константы:
   WHATSAPP_PHONE
   WHATSAPP_TEXT

3. Исправлен и унифицирован футер.
   Теперь футер есть на главной, услугах, ценах, мастерах, контактах, отзывах, странице политики и страницах отдельных услуг.

4. Картинки вынесены в отдельные папки для простой замены:
   assets/img/content/ — главная картинка и картинки услуг
   assets/img/masters/ — фото мастеров

Как заменить картинки:
- Откройте assets/img/content/ или assets/img/masters/
- Замените нужный файл новым файлом с таким же названием
- Ничего в коде менять не нужно, если название и формат файла остались такими же

Главные файлы картинок:
assets/img/content/hero-main.webp
assets/img/content/service-washer.png
assets/img/content/service-fridge.png
assets/img/content/service-microwave.png
assets/img/content/service-dishwasher.png
assets/img/content/service-stove.png
assets/img/content/service-small.png
assets/img/masters/master-1.jpg ... master-5.jpg

5. Внутренние страницы приведены к одному стилю шапки, футера и WhatsApp-кнопки.

Перед публикацией:
- Замените SITE_URL в includes/config.php на настоящий домен.
- Замените ADMIN_LOGIN и ADMIN_PASS в includes/config.php.
- Проверьте номер MAIN_PHONE и WHATSAPP_PHONE.
