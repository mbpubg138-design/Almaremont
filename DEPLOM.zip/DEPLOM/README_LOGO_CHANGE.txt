ИЗМЕНЕНИЕ ЛОГОТИПА НА ВСЁМ САЙТЕ

Я сделал отдельную папку для брендинга:
assets/img/branding/

Что можно менять:
1. assets/img/branding/site-logo.svg  — главный логотип сайта
2. assets/img/branding/phone-icon.svg — иконка рядом с телефоном
3. assets/img/branding/favicon.svg    — иконка вкладки браузера

Если просто заменить файлы с теми же именами, логотип обновится на сайте автоматически.

Если захотите использовать другой формат файла (например PNG), откройте includes/config.php
и измените пути в строках:
- SITE_LOGO_PATH
- SITE_FAVICON_PATH
- PHONE_ICON_PATH
